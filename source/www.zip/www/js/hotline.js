define(['jquery', 'jquerymobile', 'net', 'dialogs','panle'], function($, m, net, dia,panle) {

	var hotlineInfo = {
        "h_001": {
            "team": "CRE Helpdesk",
            "telNo": [{
                "name":"Telephone Number",
                "value":"Internal:   &ensp;*505"
            }],
            "Email": [{
                "name": "E-mail (GZC)",
                "value": "cre.fm.helpdesk.gzc@hsbc.com.cn"
            },
                {
                    "name": "E-mail (NHC)",
                    "value": "cre.fm.helpdesk.nhc.china.gsc@hsbc.com.cn"
                },
                {
                    "name": "E-mail (TKH)",
                    "value": "cre.fm.helpdesk.tkh@hsbc.com.cn"
                }
            ]
        },
        "h_002": {
            "team": "Security Helpdesk",
            "telNo": [{
                "name": "GZC Telephone Number",
                "value": "External:  +86 (20) 3858 1199"
            }, {
                "name": "",
                "value": "Internal:   &ensp;81199"
            }, {
                "name": "NHC Telephone Number",
                "value": "External:  +86 (757) 8583 0999"
            }, {
                "name": "",
                "value": "Internal:   &ensp;30999"
            }, {
                "name": "TKH Telephone Number",
                "value": "External:  +86 (20) 3858 0101"
            }, {
                "name": "",
                "value": "Internal:   &ensp;80101"
            }],
            "Email": [{
                "name": "E-mail (GZC/TKH)",
                "value": "securityservice.china.gsc@hsbc.com.cn"
            }, {
                "name": "E-mail (NHC)",
                "value": "fscsecurityservice.china.gsc@hsbc.com.cn"
            }]
        },
        "h_003": {
            "team": "Contingency Risk (CR) Emergency Hotline",
            "telNo": [{
                "name": "Telephone Number",
                "value":"External:  +86 (20) 3858 0911"
            }],
            "Email": []
        },
        "h_004": {
            "team": "IT Support Hotline",
            "telNo": [{
                "name": "Telephone Number",
                "value": "External:  +86 (20) 3858 3333"
            }, {
                "name": "",
                "value": "Internal:   &ensp;3333"
            }],
            "Email": []
        },
        "h_005": {
            "team": "HRDirect Hotline",
            "telNo": [{
                "name": "Telephone Number",
                "value": "External:  +86 (20) 3858 3304"
            }, {
                "name": "",
                "value": "Internal:   &ensp;3380"
            }],
            "Email": []
        },
        "h_006": {
            "team": "Account Payable Hotline",
            "telNo": [{
                "name": "Telephone Number",
                "value": "Internal:   &ensp;685278836084"
            }],
            "Email": [{
                "name": "E-mail",
                "value": "AccountsPayable@procurement-support.hsbc.com"
            }]
        }
    }
	
	var htmlTemplate = "";

    $("#hotlines").on( "pagecreate", function() {
        $( "body > [data-role='panel']" ).panel();
        $( "body > [data-role='panel'] [data-role='listview']" ).listview();
    });

	//设置内容高度是Header剩下的高度
    $("#hotlines").on( "pagebeforeshow", function( event ) {
        	$('#news_footer').hide();
        	window.setBodyOverflow($(document.body));
        	$('#hotlines-content').css('height',($(window).height()-44-20));
            $('#hotlines-content-info').css('min-height',($(window).height()-44));
            // $('#hotline_show').css('min-height',($(window).height()-44));
            // window.historyView = [];
            // 兼容其他浏览器
    });


    $('#hotline-btn-menu').off('click')
        .on('click', function() {
            $.mobile.backChangePage("#hotlines",{ transition: "slide",reverse: true,changeHash: false});
        });
    

    function compatibility() {
        /* Logon */
        $('#title_hotline').parent()
            .css('display', 'block')
            .css('postion', 'relative');

        $('#title_hotline').css('postion', 'absulute')
            .css('width', '120px')
            .css('height','20px')
            .css('margin', '8px auto auto auto')
            .css('text-align', 'center');
    }

    //动态生成列表
	function fillHotlineList(){
		if($("#hotline_show").children().length > 0){
			null;
		} else {
			$.each(hotlineInfo, function(index, val){
			    var telNoHtml = "";
			    var emailNoHtml = "";
			    if(val.telNo.length > 0){
			        $.each(val.telNo, function(index,valtel){
			            telNoHtml += "<div style='margin-left: 15px;'><div style='color: #999999'>" + valtel.name + "</div><div></div>"+valtel.value+"</div>"
                    })
                }
                if(val.Email.length > 0){
                    $.each(val.Email, function(index,valemail){
                        emailNoHtml += "<div style='margin-left: 15px;'><div style='color: #999999'>"+valemail.name+"</div><div></div>"+valemail.value+"</div>"
                    })
                }
				htmlTemplate += '<div style="height:10px;width:100%;background-color:#e4e4e4">&nbsp;</div>' +
					            '<div style="margin:0px;border-radius: 0px;list-style-type:none" data-role="listview">' +                 
					                    '<div style="font-size: 16px;margin:0px 10px;padding-top:10px;word-wrap: break-word;line-height:20px;">' + val.team + '</div>' +
					                    '<hr style="border:0;background-color:#e4e4e4;height:1px;width:100%;margin:10px 0 0 0;"/>' +
					                    '<div style="white-space: normal;font-weight: normal;line-height: 1.5;font-size: 14px;font-family: Arial;padding: 15px 0px;">' +
                                           telNoHtml +
					                        '<hr style="border:0;background-color:#e4e4e4;height:1px;"/>' +
                                           emailNoHtml +
					                    '</div>' +
					            '</div>';
			});
			$("#hotline_show").html(htmlTemplate);
		}
	}
	$(document).ready(function(){
        fillHotlineList();
		setTimeout(function() {
            // 兼容其他浏览器
            compatibility();
        },1000);
	});

});