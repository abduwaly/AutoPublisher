<?php
  echo file_get_contents("http://demoappdownload.oss-cn-hangzhou.aliyuncs.com/upload/einvoice/20170218/1111111_111111.pdf");
?>